public class checker {
    public static boolean isLogin(String login){
        if (login.length() < 3) return false;
        else return true;
    }
    public static boolean isName(String name){
        return name.matches("[A-Z][a-zA-Z]*") && name.length()>3;

    }
    public static boolean isPassword(String login){
        if (login.length() < 5) return false;
        else return true;
    }

    public static void main(String[] args) {
        registration.showRegistrationPanel(true);
    }
}
