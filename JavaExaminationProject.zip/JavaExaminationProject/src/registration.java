import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
public class registration {
    private JTextField login;
    private JComboBox comboBox1;
    private JButton registerB;
    private JPanel panel;
    private JTextField name;
    private JTextField surname;
    private JTextField password;
    private JLabel loginLabel;
    private JButton loginButton;
    private JButton singUpButton;
    private static String checkbox;
    private static JFrame frame;
    public void autoLogin(String log, String pass) {
        if (Form.checkUser(log, pass)) {
            menu menu = new menu(login.getText());
            menu.showQuestionsPanel(true);
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.dispose();
        }
        else{
            JOptionPane.showMessageDialog(null, "Your login or password is incorrect! Try again", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    public registration() {
        for (String item : config.getGroupsList()) {

            if (item != null) {
                if (!item.equals("Choose a group")) comboBox1.addItem(new comBoxObject(item, item));
                else {
                    comboBox1.addItem(new comBoxObject(null, item));
                }
            }
        }
        registerB.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!checker.isLogin(login.getText()))
                    JOptionPane.showMessageDialog(null, "Your login is lesser than 3 characters", "Error", JOptionPane.ERROR_MESSAGE);
                else {
                    if (!checker.isPassword(password.getText()))
                        JOptionPane.showMessageDialog(null, "Your password is lesser than 5 characters", "Error", JOptionPane.ERROR_MESSAGE);
                    else {
                        if (!checker.isName(name.getText()))
                            JOptionPane.showMessageDialog(null, "Not valid name,Name shouldn't be less then 3 and contain only letters.", "Error", JOptionPane.ERROR_MESSAGE);
                        else {
                            if (!checker.isName(surname.getText())  )
                                JOptionPane.showMessageDialog(null, "Not valid surname,Surname shouldn't be less then 3 and contain only letters.", "Error", JOptionPane.ERROR_MESSAGE);
                            else {
                                if (checkbox == null)
                                    JOptionPane.showMessageDialog(null, "You have not choose a group", "Error", JOptionPane.ERROR_MESSAGE);
                                else {
                                    if (Form.checkLogin(login.getText()))
                                        JOptionPane.showMessageDialog(null, "You have already registered in the system or Login is busy!", "Error", JOptionPane.ERROR_MESSAGE);
                                     else{
                                         if (Form.registrate(login.getText(), password.getText(), name.getText(), surname.getText(), checkbox)){
                                            JOptionPane.showMessageDialog(null, "You have registrated in the system", "Success", JOptionPane.INFORMATION_MESSAGE);
                                            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                                            frame.dispose();
                                            autoLogin(login.getText(), password.getText());
                                        }
                                    }
                                }

                            }
                        }
                    }
                }
            }
        });
        comboBox1.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    checkbox = comboBox1.getSelectedItem().toString();
                }
            }
        });
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login log=new login();
                log.showLoginPanel(true);
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.dispose();

            }
        });
    }

    public static void showRegistrationPanel(boolean isVisible) {
        frame = new JFrame("registration");
        frame.setContentPane(new registration().panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(isVisible);
        frame.setSize(600, 600);
        frame.setResizable(false);
    }

}