import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class login {
    private JTextField login;
    private JButton button1;
    private JPanel panel;
    private JPasswordField password;
    private JButton signInButton;
    private JButton signUpButton;
    private static JFrame frame;
    public login() {
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (Form.checkUser(login.getText(), password.getText())) {
                    menu menu = new menu(login.getText());
                    menu.showQuestionsPanel(true);
                    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    frame.dispose();
                }
                else{
                    JOptionPane.showMessageDialog(null, "Your login or password is incorrect! Try again", "Error", JOptionPane.ERROR_MESSAGE);

                }
            }
        });
        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registration reg = new registration();
                reg.showRegistrationPanel(true);
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.dispose();
            }
        });
    }

    public static void showLoginPanel(boolean isVisible) {
        frame = new JFrame("login");
        frame.setContentPane(new login().panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(isVisible);
        frame.setSize(540,400);
        frame.setResizable(false);

        }

    }
