import java.util.Random;
public class Question {
    public static String[][] questions;
    public static int numQuest;
    public static int[] flag;

    public Question (int namOfQuestions){
        questions = new String[namOfQuestions][6];
        numQuest = namOfQuestions;
        flag = new int[namOfQuestions];
    }
    public static String[][] getQuestion(){
        String[][] quests = Form.getQuestions();
        String[][] questsret = new String[numQuest][6];
        int[] randoms = new int[numQuest];
        Random rn = new Random();
        int nmqdb = (Form.numOfQuestOfDb() - 1);
        int randomed = rn.nextInt(nmqdb);
        questsret[0] = quests[randomed];
        randoms[0] = randomed;
        boolean flg = false;
        for (int i = 1; i < numQuest; i++){
            flg = false;
            for(int rd: randoms){
                if (rd == randomed){
                    randomed = rn.nextInt(nmqdb);
                    flg = true;
                    i--;
                    break;
                }
            }
            if (!flg) {
                randoms[i] = randomed;
                questsret[i] = quests[randomed];
            }
        }
        return questsret;
    }
}
